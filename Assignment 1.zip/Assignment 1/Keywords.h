#ifndef Keywords_h_INCLUDED
#define Keywords_h_INCLUDED

int Keymark[4] = {'.',',','?','!'};//punctuation pointer array
int KeymarkLen = sizeof(Keymark);//length of array, KeymarkLen = 4 as there are 4 punctuations

//same pointer array but for keywords
char *Keyword[32] = {"auto","break","case","char","const","continue","default","do","double","else","enum","extern","float","for","goto","if","int","long","register","return","short","signed","sizeof","static","struct","switch","typedef","union","unsigned","void","volatile","while"};

int KeywordLen = sizeof(Keyword)/sizeof(Keyword[0]);//length of array, KeywordLen = 32 as there  are 32 punctuations
#endif // Keywords_h_INCLUDED



