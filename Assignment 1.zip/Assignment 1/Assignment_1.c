#include <stdio.h>
#include <string.h>
#include "keywords.h"


int main(void) {
     //Declaring variables
    int i;
    int FormerState,//FormerState defines the previous state,
    linenumber = 0; // linenumber counts the number of lines
    char str[36], fread[36], fwrite[36];

    FILE *fpw = 0; // pointer in writing
	FILE *fpr = 0; // pointer in reading

    //opening the file
    while(fpr == 0) {
        printf("Name of text file: ");//Shows on the screen "Name of text file?" Then I type in the name of the text file
        scanf("%s", fread);//allows user input to recognise my text file as a string
        fpr = fopen(fread, "r");//reading text file

    printf("Name of text file to write: ");//creating a file to write, any random letter/word can be typed in
    scanf("%s", fwrite);
    fpw = fopen(fwrite, "w");//writing to file
    printf("\n");

  while (fscanf(fpr, "%s", str) != EOF)//creating a while loop, when fscanf returns to EOF it is the end of the process and it indicates that the whole file has been read ad implemented.
   {
     char PreStr[36] = {0},//initialise to be empty as I'm reading I'm putting it into new array, Present String is the new array
          UsualStr[36];

        int state = 0,//state set to 0, 0 state means there is no punctuation, or no Keywords
           len = strlen(str),
           PreStrLen = strlen(PreStr);

        //Checking for punctuation marks
        for (int i = 0; i < 4; i++) {//loop for the 4 punctuation marks to be found
            if(str[len - 1] == Keymark[i]) {

                state = 1;//1st state means there is a punctuation mark found
            }
        }

        if(state == 1) {//Check if there is a punctuation mark is there after a keyword

            strcpy(UsualStr, str);//copying a string to UsualStr from str

            //while loop checking for multiple punctuation marks
            while(1) {
                //local variables
                int
                    StateIs = 0,
                    UsualLen = strlen(UsualStr);

                //Erase last character which should be a punctuation mark
                for(int i = 0; i < UsualLen - 1; i++) {//Loop of Keymark from new destination
                    PreStr[i] = UsualStr[i];
                }

                PreStrLen = strlen(PreStr);

                //compares last character to pre-made array of punctuation marks
                for (int i = 0; i < 4; i++) {
                    if(PreStr[PreStrLen - 1] == Keymark[i]) {
                        StateIs = 1;//1st state means there is a punctuation mark found
                        break;
                    }
                }

                //check for one punctuation mark
                if(StateIs == 0){
                    break;

                //if there is punctuation mark left in a string
                //and restores newStr
                } else if(StateIs == 1) {
                    strcpy(UsualStr, PreStr);
                    memset(PreStr,0,sizeof(PreStr));//used for memory purposes as it places a particular value to a range of memory locations.
                }
            }

            //compares string to a  keyword array
            for(int i = 0; i < 32; i++) {
                if(strcmp( PreStr, Keyword[i]) == 0) {
                    state = 2;
                    break;
                }
            }

        } else {
        //Check if there is a keyword
            for(int i = 0; i < 32; i++) {//Loop of Keywords in C to be found
                if(strcmp( str, Keyword[i]) == 0) {//comparing string in textfile and a keyword and if they aren't the same, text will stay on current line

                    state = 2;//2nd state means there is a Keyword found
                }
            }
        }

        switch(state) {//a switch statement is used to make multiple decisions
            case 1 :    //state(case) 1: punctuation mark
                printf("%s \n", str);
               FormerState = 1;
               linenumber++;
                break;
            case 2 :    //state(case) 2: keyword and punctuation mark or keyword on its own

                if(FormerState == 1) {
                } else {
                    printf(" \n%s ", str);
                    linenumber++;
                }
                FormerState = 2;
                break;
            default :
                if(FormerState == 2){
                    printf(" \n%s ", str);
                     linenumber++;
                } else {
                    printf("%s ", str);
                }
                FormerState = 3;
        }
    }

	printf("\nTotal number of lines is: %d\n", linenumber += 2);


    //closing the files
    fclose(fpr);
    fclose(fpw);

    return 0;
}
}



