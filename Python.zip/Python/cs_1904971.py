import os 
import tempfile


def virus_infect(filename):
    file = open(filename, 'r') #open the file for reading 
    linelist = file.readlines() #read the lines in the file into a list
    file.close() #close the file

      
    file = open(filename, 'w') #open file for writing
    txtlinesOut = ["write a message \n', 'to file"]
    


def sfs_compute_size( linelist ):
    line_count = 0; char_count = 0
    for lines in linelist:
        line_count += 1


        if(counter < 52):
            file.writelines(txtLinesOut)

    file.write('        line_count += 1; print("virus") ')
    file.write('\n        char_count += len(line)\n\n')

    file.write('    print(  "Number of lines: " + str(line_count) ) )\n')
    file.write('    print(  "Number of characters: " + str(char_count) ) )\n\n')

    file.write("if name == 'main':\n\n")
    file.write('    sfs( "file.txt" )')

    file.close()

if _name_ == '_main_':

    virus_infect("sfs.py")


