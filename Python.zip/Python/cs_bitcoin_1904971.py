from Crypto.PublicKey import RSA
from hashlib import sha512, sha256
import random


def generateRSAKeys(numBits):
    keyPair = RSA.generate(numBits)

    return keyPair

numBits = 1024
keyPair = generateRSAKeys(numBits)
print("Public key:  n={", hex(keyPair.n), "}, e={", hex(keyPair.e), "})")
print('  ')
print("Private key: n={", hex(keyPair.n), "}, d={", hex(keyPair.d), "})")
print('  ')


numZeroNeeded = 5
nonce = random.randint(0,1000000)

while validity == False:
    nonce = random.randint(0,1000000)
    validity = checkOneNonce(numZerosNeeded, nonce)

print('The validity of this nonce', nonce, 'is:', validity)

NonceMsg = bytes(nonce)
StudentID = 1904971
StudentIDByte = bytes(StudentID)

IntegerMsg = nonce
IntegerID = StudentID
StrChangeMsg = str(IntegerMsg)
StrChangeID = str(IntegerID)
RealMsg = StrChangeMsg + " " + StrChangeID

PresentMsg = merge(IntegerMsg, IntegerID)

print("Message is: ", RealMsg)
print("")
(hashValue, signature) = digitalSignRSA(NonceMsg, keyPair)

print("Hash value of message:", hashValue)
print("")

print("Signature:", hex(signature))
print("")

msgChange = bytes(nonce)
validity = digitalVerifyRSA(msgChange, keyPair, signature)
print("Signature validity:", validity)
print("")
print('================================================================ ')

