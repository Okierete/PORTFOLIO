import sys
LETTERS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
def monoalphabetic_cipher(message, mode, key):
    ciphertext = ''
    for symbol in message:
        if symbol in LETTERS:
            num = LETTERS.find(symbol)
            Char = key.find(symbol)
            if mode == 'encrypt':
                ciphertext = ciphertext + key[num]
            elif mode == 'decrypt':
                ciphertext = ciphertext + LETTERS[Char]
            else:
                print('Correct operation mode is needed')
                exit()
            num = num % len(LETTERS)
            ciphertext = ciphertext + LETTERS[num]
        else:
            ciphertext= ciphertext + symbol
    return ciphertext

if __name__ == '__main__':
    numArgv = len(sys.argv)
    message = 'a secret message.'
    key = 'jklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghi'
    if numArgv == 2:
        message = sys.argv[1]
    elif numArgv == 3:
        message = sys.argv[1]
        key = int(sys.argv[2])
    elif numArgv > 3:
        print('+++Please input the exected message and key with correct format')
        print('+++python monnoalphabetic_cipher.py my_message key')
        print('+++where no space in my_message, key needs to be an integer for monoalphabetic cipher')
        print('+++For example: ')
        print('+++python monoalphabetic_cipher.py my_secrete_message 3')
        exit()
    mode = 'encrypt'
    ciphertext = monoalphabetic_cipher(message, mode, key)
    mode = 'decrypt'
    decrypttext = monoalphabetic_cipher(ciphertext, mode, key)
    print('##############################################')
    print('Cipher with key: ', key)
    print('##############################################')   
    print('Plain message: ', message)      
    print('Ciphertext: ', ciphertext)      
    print('Decrypted text: ', decrypttext)
#reference is the assignment 1 module document given to us in moodle,https://moodle.essex.ac.uk/course/view.php?id=3657
