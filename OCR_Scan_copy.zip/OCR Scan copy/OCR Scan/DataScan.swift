//
//  DataScan.swift
//  OCR Scan
//
//  Created by Okierete Edu on 24/02/2022.
//

import Foundation


struct DataScan:Identifiable {
    var id = UUID()
    let content:String
    
    init(content:String) { //initialize and the respective input value
        self.content = content
    }
}
