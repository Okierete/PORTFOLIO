//
//  RecogniseText.swift
//  OCR Scan
//
//  Created by Okierete Edu on 24/02/2022.
//

import Foundation
import Vision
import VisionKit

final class TextRecognizer{
    let cameraScan: VNDocumentCameraScan
    init(cameraScan:VNDocumentCameraScan) {
        self.cameraScan = cameraScan
    }
    private let queue = DispatchQueue(label: "scan-codes",qos: .default,attributes: [],autoreleaseFrequency: .workItem)
    func recognizeText(withCompletionHandler completionHandler:@escaping ([String])-> Void) {//takes input as a completion handler
        queue.async {
            let images = (0..<self.cameraScan.pageCount).compactMap({
                self.cameraScan.imageOfPage(at: $0).cgImage
            })
            let imagesAndRequests = images.map({(image: $0, request:VNRecognizeTextRequest())})
            let textPerPage = imagesAndRequests.map{image,request->String in
                let handler = VNImageRequestHandler(cgImage: image, options: [:])//Processes one or more image analysis request pertaining to a single image. Instantiating this handler to perform vision request on a single image
                do{
                    try handler.perform([request])
                    guard let observations = request.results else{return ""}//array of vision recognised text observation
                    return observations.compactMap({$0.topCandidates(1).first?.string}).joined(separator: "\n")//each observation is mapped out after each observation, and for each page a string is gotten along with a separator
                }
                catch{//catch error
                    print(error)
                    return ""
                }
            }
            DispatchQueue.main.async {
                completionHandler(textPerPage)//return text to completion handler
            }
        }
    }
}
