//
//  ContentView.swift
//  OCR Scan
//
//  Created by Okierete Edu on 24/02/2022.
//

import SwiftUI

struct ContentView: View {
    @State private var showScannerSheet = false
    @State private var texts:[DataScan] = []//takes array of scanned data and initialises as an empty array
    var body: some View {
        NavigationView{
            VStack{
                if texts.count > 0{ //if text array is not empty a list is created
                    List{
                        ForEach(texts){text in
                            NavigationLink(
                                destination:ScrollView{Text(text.content)},
                                label: {
                                    Text(text.content).lineLimit(1)
                                })
                        }
                    }
                }
                else{// if text array is empty
                    Text("Scan Document").font(.title)
                }
            }
                .navigationTitle("OCR Scan")
                .navigationBarItems(trailing: Button(action: {
                    self.showScannerSheet = true //Toggle state
                }, label: {
                    Image(systemName: "doc.text.viewfinder")
                        .font(.title)
                })
                .sheet(isPresented: $showScannerSheet, content: {
                    self.makeScannerView()
                })
                )
        }
    }
    private func makeScannerView()-> ScannerView {//returns scanner view
        ScannerView(completion: {
            textPerPage in
            if let outputText = textPerPage?.joined(separator: "\n").trimmingCharacters(in: .whitespacesAndNewlines){//joining empty spaces with the line breaks if output text = textperpage
                let newDataScan = DataScan(content: outputText)//takes output text
                self.texts.append(newDataScan)
            }
            self.showScannerSheet = false
        })
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
