//
//  OCR_ScanApp.swift
//  OCR Scan
//
//  Created by Okierete Edu on 24/02/2022.
//

import SwiftUI

@main
struct OCR_ScanApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
